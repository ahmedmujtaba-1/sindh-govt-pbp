
# Sindh Bus Booking System (Java, OOP, MVC)

A Java-based Bus Service Booking System for Hyderabad, Sindh — designed with OOP + MVC + DAO layers. Includes console UI (ready for GUI/Web extension), MySQL schema, and sample services.

## Features
- User registration/login
- Search routes & schedules
- Real-time-like seat selection (in-memory demo, DB-ready)
- Booking + Payment flow (mock payment)
- Admin: manage buses, routes, schedules

## Tech Stack
- Java 17
- Maven
- JDBC (MySQL)
- Layered Architecture (Controller → Service → Repository → DB)

## Project Structure
```
sindh-bus-booking/
├─ src/main/java/com/sindh/busbooking/
│  ├─ App.java
│  ├─ controller/
│  ├─ domain/
│  ├─ dto/
│  ├─ repository/
│  ├─ service/
│  └─ util/
├─ src/main/resources/
│  └─ schema.sql
├─ src/test/java/com/sindh/busbooking/
└─ pom.xml
```

## Local Setup
1. Install JDK 17 and Maven.
2. Create database and user in MySQL:
   ```sql
   CREATE DATABASE bus_booking CHARACTER SET utf8mb4;
   CREATE USER 'bus_user'@'localhost' IDENTIFIED BY 'bus_pass';
   GRANT ALL PRIVILEGES ON bus_booking.* TO 'bus_user'@'localhost';
   FLUSH PRIVILEGES;
   ```
3. Update DB credentials in `src/main/resources/application.properties`.
4. Run schema:
   ```bash
   mysql -u bus_user -p bus_booking < src/main/resources/schema.sql
   ```
5. Build & run:
   ```bash
   mvn clean package
   java -jar target/sindh-bus-booking-1.0.0.jar
   ```

## GitHub: Create & Push
```bash
# 1) Init repo locally
cd sindh-bus-booking
git init
git add .
git commit -m "feat: initial project skeleton"

# 2) Create repo on GitHub (from web UI) named sindh-bus-booking
# 3) Connect & push
git branch -M main
git remote add origin https://github.com/<your-username>/sindh-bus-booking.git
git push -u origin main
```

## Next Steps
- Replace in-memory implementations with MySQL repositories
- Add authentication hashing (BCrypt)
- Optional: Spring Boot migration

## License
MIT
