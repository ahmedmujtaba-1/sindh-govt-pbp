
package com.sindh.busbooking.dto;

public class BookingRequest {
    public long customerId;
    public long scheduleId;
    public String seatsCsv;

    public BookingRequest(long customerId, long scheduleId, String seatsCsv) {
        this.customerId = customerId;
        this.scheduleId = scheduleId;
        this.seatsCsv = seatsCsv;
    }
}
