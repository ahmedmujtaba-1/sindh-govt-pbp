
package com.sindh.busbooking.controller;

import com.sindh.busbooking.dto.BookingRequest;
import com.sindh.busbooking.service.BookingService;

import java.util.Scanner;

public class BookingController {
    private final BookingService bookingService = new BookingService();
    private final Scanner sc = new Scanner(System.in);

    public void search() {
        System.out.print("Origin: ");
        String origin = sc.nextLine();
        System.out.print("Destination: ");
        String dest = sc.nextLine();
        bookingService.searchSchedules(origin, dest).forEach(System.out::println);
    }

    public void book() {
        System.out.print("Schedule ID: ");
        long scheduleId = Long.parseLong(sc.nextLine());
        System.out.print("Customer ID: ");
        long customerId = Long.parseLong(sc.nextLine());
        System.out.print("Seats (e.g. 1A,1B): ");
        String seats = sc.nextLine();
        BookingRequest br = new BookingRequest(customerId, scheduleId, seats);
        System.out.println(bookingService.createBooking(br));
    }

    public void view() {
        System.out.print("Booking ID: ");
        long id = Long.parseLong(sc.nextLine());
        System.out.println(bookingService.viewBooking(id));
    }
}
