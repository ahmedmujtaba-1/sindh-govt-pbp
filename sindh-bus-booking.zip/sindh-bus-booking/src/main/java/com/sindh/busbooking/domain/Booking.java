
package com.sindh.busbooking.domain;

public class Booking {
    public long id;
    public long customerId;
    public long scheduleId;
    public String seatsCsv;
    public String status;

    @Override
    public String toString() {
        return "Booking{" +
                "id=" + id +
                ", customerId=" + customerId +
                ", scheduleId=" + scheduleId +
                ", seats='" + seatsCsv + ''' +
                ", status='" + status + ''' +
                '}';
    }
}
