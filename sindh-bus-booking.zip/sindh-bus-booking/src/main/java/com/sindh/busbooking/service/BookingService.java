
package com.sindh.busbooking.service;

import com.sindh.busbooking.domain.Booking;
import com.sindh.busbooking.dto.BookingRequest;
import com.sindh.busbooking.repository.BookingRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BookingService {
    private final BookingRepository repo = new BookingRepository();

    public List<String> searchSchedules(String origin, String dest) {
        // Demo data; replace with DB query
        List<String> demo = new ArrayList<>();
        demo.add("#1 Hyderabad → Karachi | 08:00 | Bus PBS-101");
        demo.add("#2 Hyderabad → Sukkur  | 10:00 | Bus PBS-202");
        return demo;
    }

    public String createBooking(BookingRequest req) {
        Booking b = new Booking();
        b.customerId = req.customerId;
        b.scheduleId = req.scheduleId;
        b.seatsCsv = req.seatsCsv;
        b.status = "CONFIRMED";
        repo.save(b);
        return "Booking Confirmed with ID: " + b.id;
    }

    public String viewBooking(long id) {
        Optional<Booking> b = repo.findById(id);
        return b.map(Booking::toString).orElse("Not found");
    }
}
