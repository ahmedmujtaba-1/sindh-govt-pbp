
package com.sindh.busbooking;

import com.sindh.busbooking.controller.BookingController;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BookingController controller = new BookingController();
        System.out.println("=== Sindh Bus Booking System ===");
        while (true) {
            System.out.println("1) Search Buses  2) Book Seats  3) View Booking  0) Exit");
            System.out.print("Select: ");
            String choice = sc.nextLine();
            switch (choice) {
                case "1": controller.search(); break;
                case "2": controller.book(); break;
                case "3": controller.view(); break;
                case "0": System.out.println("Khuda Hafiz!"); return;
                default: System.out.println("Invalid option");
            }
        }
    }
}
