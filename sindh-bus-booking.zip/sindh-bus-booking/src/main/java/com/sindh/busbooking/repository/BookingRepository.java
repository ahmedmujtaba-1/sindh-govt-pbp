
package com.sindh.busbooking.repository;

import com.sindh.busbooking.domain.Booking;
import java.util.*;

public class BookingRepository {
    private final Map<Long, Booking> store = new HashMap<>();
    private long seq = 1;

    public Booking save(Booking b) {
        if (b.id == 0) b.id = seq++;
        store.put(b.id, b);
        return b;
    }

    public Optional<Booking> findById(long id) {
        return Optional.ofNullable(store.get(id));
    }
}
